# UWE Bristol Creative Technology Toolkit 

https://github.com/uwe-creative-technology/CT_toolkit_sessions


example code for the Creative Technology Toolkit module on Creative Technology MSc at UWE Bristol

http://uwecreativetechnology.com

Dan Buzzo, October 2019

https://github.com/danbz

https://buzzo.com


 # Simple Particle Example

• Simple example showing use of a custom 'particle' class 

• generation of our custom particle objects and placement in a vector for drawing and updating

 ![screenshot](particleExample/particleExample-screenshot.png)
