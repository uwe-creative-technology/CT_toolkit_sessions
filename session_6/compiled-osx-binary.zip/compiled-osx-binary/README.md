# UWE Bristol Creative Technology Toolkit session six

https://github.com/uwe-creative-technology/CT_toolkit_sessions


example code for the Creative Technology Toolkit module on Creative Technology MSc at UWE Bristol

http://uwecreativetechnology.com

Dan Buzzo, October 2019

https://github.com/danbz

https://buzzo.com



# Session 6

• simple algorithms

• drunkards walk 3 ways including Perlin Noise

![screenshot](screenshot-session6.png)