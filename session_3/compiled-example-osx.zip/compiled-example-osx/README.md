# UWE Bristol Creative Technology Toolkit session three

https://github.com/uwe-creative-technology/CT_toolkit_sessions


example code for the Creative Technology Toolkit module on Creative Technology MSc at UWE Bristol

http://uwecreativetechnology.com

Dan Buzzo, September 2018

https://github.com/danbz

https://buzzo.com

# Session 3

• introduction to 3D

• 3D primitives, cameras

• sensing in 3D

• reading data from Kinect Sensor

also discussing Git and github

see also the openframeworks examples included in the standard oF install at;
• oF-rootfolder/examples/computer_vision/kinect_example
• oF-rootfolder/examples/3d/easyCamExample
• oF-rootfolder/examples/3d/3DPrimitivesExample

![screenshot](screenshot-session3-1.png)
![screenshot](screenshot-session3-2.png)
